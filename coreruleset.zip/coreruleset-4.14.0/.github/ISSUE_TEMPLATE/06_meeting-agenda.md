---
name: 'Meeting Agenda'
about: OWASP CRS Monthly Chat Agenda
title: ''
labels: ':bookmark: Meeting Agenda'
assignees: ''
---

## What happened in the meantime since the chat last month

### Outside Development

* FIXME: Please fill in

### Inside Development

#### Rules

* FIXME: Please fill in

#### CRS Sandbox

* FIXME: Please fill in

#### Security

* FIXME: Please fill in

#### Plugins

* FIXME: Please fill in

#### Documentation and Public Relations

* FIXME: Please fill in

#### Project Administration and Sponsor relationships

* FIXME: Please fill in

#### Tools

* FIXME: Please fill in

#### Containers

* FIXME: Please fill in


## Rules development, key project numbers

### PRs that have been merged since the last meeting

* FIXME: Please fill in

## Open PRs

### Open PRs marked *DRAFT* or *work in progress* or *needs action*

* FIXME: Please fill in

## How to get to our slack and join the meeting?

If you are not yet on the OWASP Slack, here is your invite: https://owasp.org/slack/invite .

Everybody is welcome to join our community chat.
